//
//  searchSheet.swift
//  macro
//
//  Created by Nouf on 07/05/2025.
//
import SwiftUI
import SwiftData
import LocalAuthentication

struct searchSheet: View {
    @Environment(\.modelContext) private var modelContext
    @StateObject private var viewModel = JournalViewModel()
    @State var searchText: String = ""
    @State private var showHiddenJournals: Bool = false

    var filteredJournals: [Journal] {
        let base = showHiddenJournals ? viewModel.journals : viewModel.journals.filter { !$0.isHidden }

        return base.filter {
            searchText.isEmpty ||
            $0.title.lowercased().contains(searchText.lowercased()) ||
            $0.journal.lowercased().contains(searchText.lowercased())
        }
        .sorted(by: { $0.modifiedDate > $1.modifiedDate })
    }

    var dateFormatter: DateFormatter {
        let formatter = DateFormatter()
        formatter.dateStyle = .short
        return formatter
    }

    var body: some View {
        ZStack {
            Color.bg.ignoresSafeArea()
            if filteredJournals.isEmpty {
                HStack {
                    Spacer()
                    VStack(alignment: .center, spacing: 14) {
                        Image("bookIcon")
                        Text("لا يوجد لديك أي مذكرات")
                            .font(.system(size: 16, weight: .semibold))
                            .foregroundStyle(.darkBlue)
                    }
                    Spacer()
                }
                .padding(.horizontal)
            } else {
                List {
                    ForEach(filteredJournals, id: \.id) { journal in
                        HStack {
                            Image("book")
                                .resizable()
                                .frame(width: 40, height: 60)
                            VStack {
                                Text(journal.title)
                                    .font(.system(size: 18, weight: .medium))
                                    .foregroundStyle(.darkerBlue)

                                Text(journal.date, formatter: dateFormatter)
                                    .font(.system(size: 14))
                                    .foregroundStyle(.lightGray)
                            }
                        }
                    }
                }
            }
        }
        .searchable(text: $searchText)
        .navigationTitle("مذكراتي")
        .onAppear {
            viewModel.fetchJournals(context: modelContext)
        }
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                Button(action: {
                    authenticateWithFaceID()
                }) {
                    Label("عرض المخفية", systemImage: "lock.open")
                        .labelStyle(.titleAndIcon)
                }
            }
        }
    }

    private func authenticateWithFaceID() {
        let context = LAContext()
        var error: NSError?

        if context.canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, error: &error) {
            let reason = "الرجاء استخدام Face ID لعرض المذكرات المخفية"

            context.evaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, localizedReason: reason) { success, _ in
                DispatchQueue.main.async {
                    if success {
                        showHiddenJournals = true
                    } else {
                        print("فشل التحقق")
                    }
                }
            }
        }
    }
}


//import SwiftUI
//import SwiftData
//import LocalAuthentication
//struct searchSheet: View {
//    var journals :[Journal]
//    @State var searchText: String = ""
//    @State private var showHiddenJournals: Bool = false
//    @State private var unlockedJournalIDs: Set<UUID> = []
////    var filteredJournals: [Journal] {
////        let visible = journals.filter { !$0.isHidden }
////        let hidden = journals.filter { $0.isHidden }
////        let shown = showHiddenJournals ? (visible + hidden) : visible
////        return shown.filter{(
////            searchText.isEmpty || $0.title.lowercased().contains(searchText.lowercased()) || $0.journal.lowercased().contains(searchText.lowercased()) && !$0.isHidden)
////        }.sorted(by: {$0.modifiedDate > $1.modifiedDate})
////    }
//    var filteredJournals: [Journal] {
//        return journals.filter {
//            (!$0.isHidden || unlockedJournalIDs.contains($0.id)) &&
//            (searchText.isEmpty ||
//             $0.title.lowercased().contains(searchText.lowercased()) ||
//             $0.journal.lowercased().contains(searchText.lowercased()))
//        }
//        .sorted(by: { $0.modifiedDate > $1.modifiedDate })
//    }
//    var dateFormatter: DateFormatter {
//            let formatter = DateFormatter()
//            formatter.dateStyle = .short //to be only numbers
//            return formatter
//        }
//    
//    var body: some View {
//        ZStack{
//            Color.bg
//                .ignoresSafeArea()
//            if filteredJournals.isEmpty {
//                HStack{
//                    Spacer()
//                    VStack(alignment: .center, spacing: 14){
//                        Image("bookIcon")
//                        Text("لا يوجد لديك أي مذكرات")
//                            .font(.system(size: 16, weight: .semibold))
//                            .foregroundStyle(.darkBlue)
//                    }
//                    Spacer()
//                }
//                .padding(.horizontal)
//                
//            }
//            else {
//            List{
//                
//                    ForEach(filteredJournals, id: \.id){
//                        journal in
//                        /*NavigationLink(/*destination: journalView(journalId: journal.id)*/)*//*{*/
//                        HStack{
//                            Image("book")
//                                .resizable()
//                                .frame(width: 40, height: 60 )
//                            VStack {
//                                Text("\(journal.title)")
//                                    .font(.system(size: 18, weight: .medium))
//                                    .foregroundStyle(.darkerBlue)
//                                
//                                Text("\(journal.date, formatter: dateFormatter)")
//                                    .font(.system(size: 14))
//                                    .foregroundStyle(.lightGray)
//
//                                if journal.isHidden && !unlockedJournalIDs.contains(journal.id) {
//                                    Button("اعرض المذكرة") {
//                                        authenticateToUnlock(journal: journal)
//                                    }
//                                    .foregroundColor(.purple)
//                                    .font(.system(size: 14, weight: .medium))
//                                }
//                            }
//                            //                        }
//                        }
//                    }
//                }
//            
//            }
//           
//        }
//        .searchable(text: $searchText)
//        .navigationTitle(Text("مذكراتي"))
//        .toolbar {
//            ToolbarItem(placement: .navigationBarTrailing) {
//                Button(action: {
//                    authenticateWithFaceID()
//                }) {
//                    Label("عرض المخفية", systemImage: "lock.open")
//                        .labelStyle(.titleAndIcon)
//                }
//            }
//        }
//    }
//
//
//
//
//    private func authenticateWithFaceID() {
//        let context = LAContext()
//        var error: NSError?
//
//        if context.canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, error: &error) {
//            let reason = "الرجاء استخدام Face ID لعرض المذكرات المخفية"
//
//            context.evaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, localizedReason: reason) { success, authenticationError in
//                DispatchQueue.main.async {
//                    if success {
//                        showHiddenJournals = true
//                    } else {
//                        print("فشل التحقق: \(authenticationError?.localizedDescription ?? "غير معروف")")
//                    }
//                }
//            }
//        } else {
//            print("Face ID غير مدعوم: \(error?.localizedDescription ?? "غير معروف")")
//        }
//    }
//    private func authenticateToUnlock(journal: Journal) {
//        let context = LAContext()
//        var error: NSError?
//
//        if context.canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, error: &error) {
//            let reason = "الرجاء استخدام Face ID لعرض هذه المذكرة"
//
//            context.evaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, localizedReason: reason) { success, _ in
//                DispatchQueue.main.async {
//                    if success {
//                        unlockedJournalIDs.insert(journal.id)
//                    }
//                }
//            }
//        }
//    }
//}
//#Preview {
//    searchSheet()
//    
//    
//}

//
//import SwiftUI
//import SwiftData
//struct searchSheet: View {
//    var journals :[Journal]
//    @State var searchText: String = ""
//    var filteredJournals: [Journal] {
//        return journals.filter{(
//            searchText.isEmpty || $0.title.lowercased().contains(searchText.lowercased()) || $0.journal.lowercased().contains(searchText.lowercased()) && !$0.isHidden)
//        }.sorted(by: {$0.modifiedDate > $1.modifiedDate})
//    }
//    
//    var dateFormatter: DateFormatter {
//            let formatter = DateFormatter()
//            formatter.dateStyle = .short //to be only numbers
//            return formatter
//        }
//    
//    var body: some View {
//        ZStack{
//            Color.bg
//                .ignoresSafeArea()
//            if filteredJournals.isEmpty {
//                HStack{
//                    Spacer()
//                    VStack(alignment: .center, spacing: 14){
//                        Image("bookIcon")
//                        Text("لا يوجد لديك أي مذكرات")
//                            .font(.system(size: 16, weight: .semibold))
//                            .foregroundStyle(.darkBlue)
//                    }
//                    Spacer()
//                }
//                .padding(.horizontal)
//                
//            }
//            else {
//            List{
//                
//                    ForEach(filteredJournals, id: \.id){
//                        journal in
//                        /*NavigationLink(/*destination: journalView(journalId: journal.id)*/)*//*{*/
//                        HStack{
//                            Image("book")
//                                .resizable()
//                                .frame(width: 40, height: 60 )
//                            VStack {
//                                Text("\(journal.title)")
//                                    .font(.system(size: 18, weight: .medium))
//                                    .foregroundStyle(.darkerBlue)
//                                
//                                Text("\(journal.date, formatter: dateFormatter)")
//                                    .font(.system(size: 14))
//                                    .foregroundStyle(.lightGray)
//                                
//                            }
//                            //                        }
//                        }
//                    }
//                }
//            
//            }
//           
//        }
//        .searchable(text: $searchText)
//        .navigationTitle(Text("مذكراتي"))
//    }
//}
//
//#Preview {
//    searchSheet()
//}
